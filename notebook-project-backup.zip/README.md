﻿# 时间笔记（Time Notebook）

这是一个手机优先的本地笔记 PWA，包含时间轴笔记、计时、手写草图、图片、日记、习惯打卡、统计、备份与手动同步。

## 目录

- `outputs/notebook-app/`：PWA 源码，用于部署到 HTTPS 静态托管。
- `outputs/notebook.html`：电脑单文件版，可直接双击打开。
- `outputs/notebook-app.zip`：Cloudflare Pages、Netlify 等静态托管的部署包。
- `work/build-release.ps1`：重建单文件版和 zip。
- `work/release-check.ps1`：发布前静态检查和真实交互回归检查。
- `work/release-battery.html`：自动化交互测试用例。
- `docs/对话重要内容.md`：本对话整理出的长期上下文。
- `docs/功能与架构说明.md`：功能、数据结构和实现说明。
- `docs/部署方案.md`：Netlify 限制和 Cloudflare Pages 推荐部署流程。
- `docs/本机环境与维护须知.md`：本机工具限制与后续维护注意事项。

## 快速使用

电脑直接打开：

`outputs/notebook.html`

手机部署：

上传 `outputs/notebook-app.zip` 到 Cloudflare Pages，然后手机打开生成的 `*.pages.dev` 网址并安装应用。

## 发布前检查

在项目根目录运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\work\release-check.ps1
```

必须打开并查看：

- `work/release-check-1.png`：应显示绿色“✅ 全部通过”。
- `work/release-check-2.png`：应显示数据在重新打开后仍然存在。

## 当前数据规则

- 文字、日记、打卡：localStorage。
- 图片、草图：优先 IndexedDB，另有本地媒体仓库降级方案。
- 图片时间轴只加载约 360px 缩略图，点击后才加载原图。
- 同步链接目前只同步文字、日记、打卡和习惯，不含图片和草图。
- 完整图片备份请使用“更多 → 导出笔记”，导出 JSON 后再导入另一台设备。