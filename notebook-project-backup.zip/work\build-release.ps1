﻿# 时间笔记 · 从 notebook-app/index.html 重建单文件版与部署 zip
# 用法: powershell -ExecutionPolicy Bypass -File .\work\build-release.ps1
$ErrorActionPreference = "Stop"
$work = $PSScriptRoot
$root = Split-Path -Parent $work
$out  = Join-Path $root "outputs"
$app  = Join-Path $out "notebook-app"
$idxPath = Join-Path $app "index.html"
$soloPath = Join-Path $out "notebook.html"
$zipPath = Join-Path $out "notebook-app.zip"

$html = [System.IO.File]::ReadAllText($idxPath, [System.Text.Encoding]::UTF8)
$solo = $html
$solo = $solo.Replace('<link rel="manifest" href="manifest.json">' + "`r`n", '')
$solo = $solo.Replace('<link rel="manifest" href="manifest.webmanifest">' + "`r`n", '')
$solo = $solo.Replace('<link rel="apple-touch-icon" href="apple-touch-icon.png">' + "`r`n", '')
$solo = $solo.Replace('<link rel="icon" href="icon-192.png">' + "`r`n", '')
$solo = $solo -replace '(?s)\s*if\("serviceWorker" in navigator.*?\n  \}\n', "`r`n"
$utf8 = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($soloPath, $solo, $utf8)
Compress-Archive -Path (Join-Path $app '*') -DestinationPath $zipPath -CompressionLevel Optimal -Force
Write-Host "✅ 已重建 outputs/notebook.html"
Write-Host "✅ 已重建 outputs/notebook-app.zip"