﻿# 时间笔记 · 项目规则

## 发布前必须检查（每次改动 outputs 都要做，不可跳过）

任何一次生成或更新 `outputs/notebook-app*`、`outputs/notebook.html`、`outputs/notebook-app.zip` 之前，必须：

1. 运行固定检查脚本：

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\work\release-check.ps1
   ```

2. 脚本做三件事：
   - **静态检查**：文件齐全、manifest 合法、图标尺寸正确、Service Worker 可用、
     页面无外部资源引用（离线可用）、zip 内容完整，并校验
     **zip 里的 index.html 与最新源码逐字一致**（防止交付过期包）
   - **动态回归**：390x844 手机视口下跑真实交互 —— 空状态启动、写文字、手写草图 + 大图、
     计时开始/停止、导出（要求含附件）、导入坏文件（要求数据不被破坏）、
     XSS 注入（要求不生成标签、不执行脚本、文本被转义）、250 条大数据分页、
     重开持久化、JS 错误数必须为 0
   - 输出两张截图：`work/release-check-1.png`（判定横幅）、`work/release-check-2.png`（重开数据仍在）

3. 必须**实际打开这两张截图**确认：横幅为绿色「✅ 全部通过」，第二次打开数据还在。
   任何一项为红，修完重新跑，不允许带问题交付。

4. 回复里如实报告：修了什么、验证了什么、仍存在的限制（不要只报喜）。

## 已知设计约束（属取舍，不要当作 bug 反复"修"）

- 笔记存本机：文字在 localStorage，草图在 IndexedDB；`file://` 打开时浏览器禁用 IndexedDB，
  会自动降级为内联存储（已实现并有测试覆盖）。
- 跨设备实时同步需要服务器，目前未实现；免费 Netlify 也没有访问密码。
- `outputs/notebook.html` 是电脑单文件版，故意不含 PWA/离线部分。

## 本机环境注意

- PowerShell 的 HTTPS 在本机不可用（Schannel 证书层被拦），Chrome 可正常渲染本地文件与截图。
- Chrome 的 `--dump-dom` 和自动下载在本机会挂起，所以检查结果通过截图呈现，不要改用它们。
- 改 JS 文件时用 here-string 或单引号字符串，禁止在双引号里写 JS 引号，避免把代码写坏。

## APK / TWA 流程（当用户要"真正的应用"时）

1. 方案 A（PWA 安装应用）在没有 Google 服务的国产手机上装不出 WebAPK，只能得到书签（必带地址栏）。
2. 方案 B：用户在 https://www.pwabuilder.com 用 `https://adorable-ganache-7e425b.netlify.app`
   生成 Android 包（Package ID 用 `com.timenote.notebook`），下载的 zip 里有
   `app-release-signed.apk`、`assetlinks.json`、`signing.keystore`。
3. 用户把 `assetlinks.json`（或 SHA-256 指纹）发来后，运行：
   `powershell -ExecutionPolicy Bypass -File .\work\make-assetlinks.ps1 -JsonPath "<路径>"`
   它会写入 `outputs/notebook-app/.well-known/assetlinks.json` 并重建 zip。
4. 之后必须：重新部署 → 验证 `/.well-known/assetlinks.json` 可访问 → 再让用户装 APK
   （顺序反了 Chrome 会记住"没有 assetlinks"，地址栏不会消失）。
5. 用户换浏览器/换 App 后存储空间不同：提醒先导出再导入。

## 血泪教训（务必遵守）

- **不要在 CSS 和 JS 里使用同一个注释作为锚点**（例如 `/* ---------- 日记本 ---------- */`）：
  PowerShell 的 `String.Replace` 会命中两处，把 CSS 复制进 JS，产生语法错误、整个应用白屏。
  插入 CSS 请用 `<style>` 区独有的锚点（如 `/* ---------- print ---------- */`），或改用「按索引切片插入」。
- 每次改完 `index.html` 都必须先做一次「语法/启动自检」：跑 `work/release-check.ps1`，
  看 `release-check-1.png` 顶部横幅必须绿色；任何 `SyntaxError` 都会让时钟停在 `--:--`。
