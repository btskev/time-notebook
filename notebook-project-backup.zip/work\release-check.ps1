﻿# 时间笔记 · 发布前自动检查（配套 work/release-battery.html）
# 用法: powershell -ExecutionPolicy Bypass -File .\work\release-check.ps1
$ErrorActionPreference = "Stop"
$work = $PSScriptRoot
$root = Split-Path -Parent $work
$out  = Join-Path $root 'outputs'
$app  = Join-Path $out 'notebook-app'

$fail = @()
function Check($name, $cond, $detail){
  if($cond){ Write-Host ("  [OK]   " + $name + $(if($detail){" --- $detail"})) }
  else { Write-Host ("  [FAIL] " + $name + $(if($detail){" --- $detail"})); $script:fail += $name }
}

Write-Host "== 1/3 静态检查 =="
$idx  = Join-Path $app 'index.html'
$man  = Join-Path $app 'manifest.json'
$sw   = Join-Path $app 'sw.js'
$solo = Join-Path $out 'notebook.html'
$zip  = Join-Path $out 'notebook-app.zip'
$bat  = Join-Path $work 'release-battery.html'
foreach($p in @($idx,$man,$sw,$solo,$zip,$bat)){ Check ("存在 " + (Split-Path $p -Leaf)) (Test-Path $p) }
if($fail.Count -gt 0){ Write-Host "== 结果: FAIL (缺少文件) =="; exit 1 }

$html = Get-Content -Raw -LiteralPath $idx
$m = $null
try { $m = Get-Content -Raw -LiteralPath $man | ConvertFrom-Json } catch {}
Check "manifest 是合法 JSON" ($null -ne $m)
Check "manifest 关键字段" ($m -and $m.name -and $m.start_url -and $m.display) ("display=" + $m.display)
Check "manifest 图标 >= 3" ($m.icons.Count -ge 3) ("count=" + $m.icons.Count)
Check "页面无外部资源引用" (-not ($html -match 'src\s*=\s*["'']https?://')) ""
Check "注册 Service Worker" ($html.Contains('serviceWorker')) ""
Check "含安装入口" ($html.Contains('btnInstall')) ""
Check "含手写画板" ($html.Contains('sketchCanvas')) ""
Check "含图片附件" ($html.Contains('id="imageInput"' ) -and $html.Contains('photoStripHtml')) ""
Check "含图片缩略图优化" ($html.Contains('fileGetThumb') -and $html.Contains('MAX_THUMB_EDGE')) ""
Check "含导入清洗" ($html.Contains('function sanitize')) ""
Check "含属性转义" ($html.Contains('&#39;')) ""
$swSrc = Get-Content -Raw -LiteralPath $sw
$manLegacy = Join-Path $app 'manifest.webmanifest'
Check "旧 manifest.webmanifest 仍保留（兼容）" (Test-Path $manLegacy) ""
if(Test-Path $manLegacy){
  $a1 = (Get-Content -Raw -LiteralPath $man).Trim()
  $a2 = (Get-Content -Raw -LiteralPath $manLegacy).Trim()
  Check "两份 manifest 内容一致" ($a1 -eq $a2) "不一致时会指向不同配置"
}
Check "SW 有 fetch 处理" ($swSrc.Contains('addEventListener("fetch"')) ""
Check "SW 导航网络优先" ($swSrc.Contains('isDoc')) ""
$soloSrc = Get-Content -Raw -LiteralPath $solo
Check "单文件版无 SW 引用" (-not $soloSrc.Contains('serviceWorker')) ""
Add-Type -AssemblyName System.Drawing
foreach($ico in @($m.icons)){
  $ip = Join-Path $app $ico.src
  $okFile = Test-Path $ip
  Check ("manifest 图标存在 " + $ico.src) $okFile ""
  if($okFile -and $ico.sizes -match '^(\d+)x(\d+)$'){
    $im = [System.Drawing.Image]::FromFile($ip)
    Check ("manifest 图标尺寸相符 " + $ico.src) (($im.Width -eq [int]$Matches[1]) -and ($im.Height -eq [int]$Matches[2])) ($im.Width.ToString() + "x" + $im.Height)
    $im.Dispose()
  }
}
foreach($sc in @($m.screenshots)){
  if(-not $sc.src){ continue }
  $sp = Join-Path $app $sc.src
  $okFile = Test-Path $sp
  Check ("manifest 截图存在 " + $sc.src) $okFile ("form_factor=" + $sc.form_factor)
  if($okFile -and $sc.sizes -match '^(\d+)x(\d+)$'){
    $im = [System.Drawing.Image]::FromFile($sp)
    Check ("manifest 截图尺寸相符 " + $sc.src) (($im.Width -eq [int]$Matches[1]) -and ($im.Height -eq [int]$Matches[2])) ($im.Width.ToString() + "x" + $im.Height)
    $im.Dispose()
  }
}
$expect = @{ 'icon-192.png'=192; 'icon-512.png'=512; 'maskable-512.png'=512; 'apple-touch-icon.png'=180 }
foreach($k in $expect.Keys){
  $p = Join-Path $app $k
  if(Test-Path $p){
    $img = [System.Drawing.Image]::FromFile($p)
    Check ("图标尺寸 " + $k) ($img.Width -eq $expect[$k] -and $img.Height -eq $expect[$k]) ($img.Width.ToString() + "x" + $img.Height)
    $img.Dispose()
  } else { Check ("图标存在 " + $k) $false "" }
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$z = [System.IO.Compression.ZipFile]::OpenRead($zip)
$names = @($z.Entries | ForEach-Object { $_.FullName })
$z.Dispose()
foreach($need in @('index.html','manifest.json','manifest.webmanifest','sw.js','icon-192.png','icon-512.png','apple-touch-icon.png')){
  Check ("zip 内含 " + $need) ($names -contains $need) ""
}
$zi = [System.IO.Compression.ZipFile]::OpenRead($zip)
$entry = $zi.Entries | Where-Object { $_.FullName -eq "index.html" } | Select-Object -First 1
$sr = New-Object System.IO.StreamReader($entry.Open())
$zipIndexText = $sr.ReadToEnd(); $sr.Close(); $zi.Dispose()
Check "zip 内 index.html 与最新源码一致" ($zipIndexText.Trim() -eq $html.Trim()) "不一致说明打包过期，必须重新打包"

Write-Host "== 2/3 动态回归（390x844 手机视口） =="
$batteryText = Get-Content -Raw -LiteralPath $bat
$clearHead = '<script>try{localStorage.removeItem("time-notebook-v1");localStorage.removeItem("tn_last_backup");}catch(e){}</script>'
$test = $html -replace '<head>', ("<head>`n" + $clearHead)
$test = $test -replace '</body>', ($batteryText + "`n</body>")
$srcPath = Join-Path $work 'release-check-src.html'
Set-Content -LiteralPath $srcPath -Value $test -Encoding UTF8
$frame = Join-Path $work 'release-check-frame.html'
$frameHtml = @"
<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;height:100%;background:#0B1220;display:grid;place-items:center}
.phone{width:390px;height:844px;border-radius:26px;overflow:hidden;box-shadow:0 30px 70px -30px #000}
iframe{width:100%;height:100%;border:0;display:block}</style></head><body>
<div class="phone"><iframe src="release-check-src.html#test"></iframe></div></body></html>
"@
Set-Content -LiteralPath $frame -Value $frameHtml -Encoding UTF8
$chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
$prof = Join-Path $work 'release-check-profile'
if(-not (Test-Path $prof)){ New-Item -ItemType Directory -Force -Path $prof | Out-Null }
$shot1 = Join-Path $work 'release-check-1.png'
$shot2 = Join-Path $work 'release-check-2.png'
$a1 = @('--headless=new','--no-sandbox','--disable-gpu','--no-first-run','--allow-file-access-from-files',"--user-data-dir=$prof",'--hide-scrollbars','--force-device-scale-factor=2','--window-size=520,900','--virtual-time-budget=60000',"--screenshot=$shot1",('file:///' + $frame.Replace('\','/')))
(Start-Process -FilePath $chrome -ArgumentList $a1 -PassThru -WindowStyle Hidden).WaitForExit(90000) | Out-Null
$a2 = @('--headless=new','--no-sandbox','--disable-gpu','--no-first-run','--allow-file-access-from-files',"--user-data-dir=$prof",'--hide-scrollbars','--force-device-scale-factor=2','--window-size=520,900','--virtual-time-budget=4000',"--screenshot=$shot2",('file:///' + $idx.Replace('\','/')))
(Start-Process -FilePath $chrome -ArgumentList $a2 -PassThru -WindowStyle Hidden).WaitForExit(60000) | Out-Null
Write-Host ("  截图1（交互 + 判定横幅）: " + $shot1)
Write-Host ("  截图2（重开持久化验证）: " + $shot2)
Check "两张巡检截图已生成" ((Test-Path $shot1) -and (Test-Path $shot2))

Write-Host ""
Write-Host "== 3/3 结论 =="
if($fail.Count){
  Write-Host ("  ❌ " + $fail.Count + " 项未通过：")
  $fail | ForEach-Object { Write-Host ("     - " + $_) }
  exit 1
}
Write-Host "  ✅ 静态检查全部通过。请打开截图1确认横幅为绿色「✅ 全部通过」，截图2确认重开后数据仍在。"








