﻿# 离线生成二维码（QR Code v3-L，字节模式），带自检
param([string]$Text = "https://adorable-ganache-7e425b.netlify.app", [string]$Out = "")
$ErrorActionPreference = "Stop"

# ---- GF(256) ----
$exp = New-Object int[] 512
$log = New-Object int[] 256
$x = 1
for($i=0;$i -lt 255;$i++){ $exp[$i]=$x; $log[$x]=$i; $x = $x -shl 1; if($x -band 0x100){ $x = $x -bxor 0x11D } }
for($i=255;$i -lt 512;$i++){ $exp[$i]=$exp[$i-255] }
function GfMul([int]$a,[int]$b){ if($a -eq 0 -or $b -eq 0){ return 0 }; return $exp[($log[$a]+$log[$b]) % 255] }

# ---- 数据码字（v3-L：55 数据 + 15 纠错 = 70）----
$bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
if($bytes.Length -gt 53){ throw ("内容过长: " + $bytes.Length + " 字节") }
$bits = New-Object System.Collections.Generic.List[int]
function PushBits([int]$val,[int]$len){ for($i=$len-1;$i -ge 0;$i--){ $script:bits.Add(($val -shr $i) -band 1) } }
PushBits 4 4                # 字节模式
PushBits $bytes.Length 8
foreach($b in $bytes){ PushBits $b 8 }
$capBits = 55*8
for($i=0;$i -lt 4 -and $bits.Count -lt $capBits;$i++){ $bits.Add(0) }   # 终止符
while(($bits.Count % 8) -ne 0){ $bits.Add(0) }                          # 补齐到字节
$dataCw = New-Object System.Collections.Generic.List[int]
for($i=0;$i -lt $bits.Count;$i+=8){
  $v=0; for($j=0;$j -lt 8;$j++){ $v = ($v -shl 1) -bor $bits[$i+$j] }
  $dataCw.Add($v)
}
$pad = @(0xEC,0x11); $k=0
while($dataCw.Count -lt 55){ $dataCw.Add($pad[$k % 2]); $k++ }

# ---- 纠错码字 ----
$g = @(1)
for($i=0;$i -lt 15;$i++){
  $ng = New-Object int[] ($g.Length+1)
  for($j=0;$j -lt $g.Length;$j++){
    $ng[$j]   = $ng[$j]   -bxor $g[$j]
    $ng[$j+1] = $ng[$j+1] -bxor (GfMul $g[$j] $exp[$i])
  }
  $g = $ng
}
$rem = New-Object int[] ($dataCw.Count + 15)
for($i=0;$i -lt $dataCw.Count;$i++){ $rem[$i]=$dataCw[$i] }
for($i=0;$i -lt $dataCw.Count;$i++){
  $coef = $rem[$i]
  if($coef -ne 0){ for($j=1;$j -lt $g.Length;$j++){ $rem[$i+$j] = $rem[$i+$j] -bxor (GfMul $g[$j] $coef) } }
}
$allCw = New-Object int[] 70
for($i=0;$i -lt 55;$i++){ $allCw[$i]=$dataCw[$i] }
for($i=0;$i -lt 15;$i++){ $allCw[55+$i]=$rem[55+$i] }

# ---- 自检1：RS 校验（所有根代入应为 0）----
$syndromeOk = $true
for($s=0;$s -lt 15;$s++){
  $acc=0
  for($i=0;$i -lt 70;$i++){
    $p = 70-1-$i
    $acc = $acc -bxor (GfMul $allCw[$i] $exp[($s*$p) % 255])
  }
  if($acc -ne 0){ $syndromeOk=$false }
}

# ---- 矩阵 ----
$size=29
$m = [Array]::CreateInstance([int], $size, $size)
$f = [Array]::CreateInstance([bool], $size, $size)
function SetF([int]$r,[int]$c,[int]$v){ $m[$r,$c]=$v; $f[$r,$c]=$true }
# finder + separator
foreach($pos in @(,@(0,0)) + @(,@(0,($size-7))) + @(, @(($size-7),0))){
  $r0=$pos[0]; $c0=$pos[1]
  for($r=-1;$r -le 7;$r++){ for($c=-1;$c -le 7;$c++){
    $rr=$r0+$r; $cc=$c0+$c
    if($rr -lt 0 -or $cc -lt 0 -or $rr -ge $size -or $cc -ge $size){ continue }
    $v=0
    if($r -ge 0 -and $r -le 6 -and $c -ge 0 -and $c -le 6){
      $edge = ($r -eq 0 -or $r -eq 6 -or $c -eq 0 -or $c -eq 6)
      $core = ($r -ge 2 -and $r -le 4 -and $c -ge 2 -and $c -le 4)
      if($edge -or $core){ $v=1 }
    }
    SetF $rr $cc $v
  }}
}
# timing
for($i=8;$i -lt $size-8;$i++){ $v = if($i % 2 -eq 0){1}else{0}; SetF 6 $i $v; SetF $i 6 $v }
# alignment (v3: 中心 22,22)
for($r=-2;$r -le 2;$r++){ for($c=-2;$c -le 2;$c++){
  $black = ([Math]::Abs($r) -eq 2 -or [Math]::Abs($c) -eq 2 -or ($r -eq 0 -and $c -eq 0))
  SetF (22+$r) (22+$c) $(if($black){1}else{0})
}}
# 暗模块
SetF (4*3+9) 8 1
# 版本信息（v3 不需要）

# ---- 格式信息（L=01, mask=000）----
$data5 = (1 -shl 3) -bor 0     # 01 000
$remBits = $data5
for($i=0;$i -lt 10;$i++){ $remBits = ($remBits -shl 1) -bxor (((($remBits -shr 9) -band 1)) * 0x537) }
$fmt = (($data5 -shl 10) -bor ($remBits -band 0x3FF)) -bxor 0x5412
function FmtBit([int]$i){ return (($fmt -shr $i) -band 1) }
for($i=0;$i -le 5;$i++){ SetF 8 $i (FmtBit $i) }
SetF 8 7 (FmtBit 6); SetF 8 8 (FmtBit 7); SetF 7 8 (FmtBit 8)
for($i=9;$i -lt 15;$i++){ SetF (14-$i) 8 (FmtBit $i) }
for($i=0;$i -lt 8;$i++){ SetF 8 ($size-1-$i) (FmtBit $i) }
for($i=8;$i -lt 15;$i++){ SetF (8) ($size-15+$i) (FmtBit $i) }
SetF 8 ($size-8) 1

# ---- 放置数据码字 ----
$bitIdx=0; $total=$allCw.Length*8
for($right=$size-1; $right -ge 1; $right-=2){
  if($right -eq 6){ $right=5 }
  for($vert=0;$vert -lt $size;$vert++){
    for($j=0;$j -lt 2;$j++){
      $c=$right-$j
      $upward = ((($right+1) -band 2) -eq 0)
      $r = if($upward){ $size-1-$vert } else { $vert }
      if(-not $f[$r,$c] -and $bitIdx -lt $total){
        $byteIdx=[Math]::Floor($bitIdx/8)
        $bit = ($allCw[$byteIdx] -shr (7-($bitIdx % 8))) -band 1
        $m[$r,$c]=$bit
        $bitIdx++
      }
    }
  }
}
# ---- 掩码 0: (r+c)%2==0 反转（仅非功能模块）----
for($r=0;$r -lt $size;$r++){ for($c=0;$c -lt $size;$c++){
  if(-not $f[$r,$c] -and ((($r+$c) % 2) -eq 0)){ $m[$r,$c] = 1 - $m[$r,$c] }
}}

# ---- 自检2：从矩阵反解数据，比较原文字节 ----
$bitsOut = New-Object System.Collections.Generic.List[int]
for($right=$size-1; $right -ge 1; $right-=2){
  if($right -eq 6){ $right=5 }
  for($vert=0;$vert -lt $size;$vert++){
    for($j=0;$j -lt 2;$j++){
      $c=$right-$j
      $upward = ((($right+1) -band 2) -eq 0)
      $r = if($upward){ $size-1-$vert } else { $vert }
      if(-not $f[$r,$c]){
        $v=$m[$r,$c]
        if((($r+$c) % 2) -eq 0){ $v = 1-$v }
        $bitsOut.Add($v)
      }
    }
  }
}
$mode=0; for($i=0;$i -lt 4;$i++){ $mode = ($mode -shl 1) -bor $bitsOut[$i] }
$len=0;  for($i=4;$i -lt 12;$i++){ $len = ($len -shl 1) -bor $bitsOut[$i] }
$decoded = New-Object System.Collections.Generic.List[byte]
for($b=0;$b -lt $len;$b++){
  $v=0
  for($j=0;$j -lt 8;$j++){ $v = ($v -shl 1) -bor $bitsOut[12 + $b*8 + $j] }
  $decoded.Add([byte]$v)
}
$roundTrip = ($mode -eq 4) -and ($len -eq $bytes.Length) -and ($decoded.Count -eq $bytes.Length)
if($roundTrip){
  for($i=0;$i -lt $bytes.Length;$i++){ if($decoded[$i] -ne $bytes[$i]){ $roundTrip=$false; break } }
}

# ---- 自检3：把格式信息从矩阵里读回来 ----
$rb = New-Object int[] 15
for($i=0;$i -le 5;$i++){ $rb[$i] = $m[8,$i] }
$rb[6]=$m[8,7]; $rb[7]=$m[8,8]; $rb[8]=$m[7,8]
for($i=9;$i -lt 15;$i++){ $rb[$i]=$m[(14-$i),8] }
$fmtBack=0
for($i=14;$i -ge 0;$i--){ $fmtBack = ($fmtBack -shl 1) -bor $rb[$i] }
$fmtOk = ($fmtBack -eq $fmt)
$ecBitsOk = (((($fmt -bxor 0x5412) -shr 10) -band 0x1F) -eq $data5)
Write-Host ("RS 校验: " + $(if($syndromeOk){"通过"}else{"失败"}))
Write-Host ("格式信息: " + $(if($fmtOk -and $ecBitsOk){"通过"}else{"失败"}) + " (网格读回=" + $fmtBack + " 期望=" + $fmt + ")")
Write-Host ("矩阵反解: " + $(if($roundTrip){"通过"}else{"失败"}) + "  模式=" + $mode + " 长度=" + $len)
Write-Host ("内容: " + $Text + "  (" + $bytes.Length + " 字节)")

if(-not $syndromeOk -or -not $roundTrip -or -not $fmtOk -or -not $ecBitsOk){ throw "二维码自检未通过，放弃输出" }

# ---- 渲染 PNG ----
Add-Type -AssemblyName System.Drawing
$scale = 14; $quiet = 4
$px = ($size + $quiet*2) * $scale
$bmp = New-Object System.Drawing.Bitmap($px,$px)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.Clear([System.Drawing.Color]::White)
$brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255,22,35,58))
for($r=0;$r -lt $size;$r++){ for($c=0;$c -lt $size;$c++){
  if($m[$r,$c] -eq 1){
    $x = ($c+$quiet)*$scale; $y = ($r+$quiet)*$scale
    $g.FillRectangle($brush,$x,$y,$scale,$scale)
  }
}}
if(-not $Out -or $Out -eq ""){ $Out = Join-Path (Get-Location) "qr.png" }
$bmp.Save($Out,[System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
Write-Host ("输出: " + $Out + "  " + $px + "x" + $px + "px")




