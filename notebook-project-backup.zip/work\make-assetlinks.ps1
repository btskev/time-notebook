﻿# 生成 .well-known/assetlinks.json（TWA 去掉地址栏的关键），并重建发布包
# 用法示例：
#   powershell -ExecutionPolicy Bypass -File .\work\make-assetlinks.ps1 -Fingerprint "AA:BB:CC:..."
#   powershell -ExecutionPolicy Bypass -File .\work\make-assetlinks.ps1 -JsonPath "C:\path\assetlinks.json"
param(
  [string]$Fingerprint = "",
  [string]$JsonPath = "",
  [string]$PackageName = "com.timenote.notebook",
  [string]$AppName = "时间笔记"
)
$ErrorActionPreference = "Stop"
$work = $PSScriptRoot
$root = Split-Path -Parent $work
$out  = Join-Path $root 'outputs'
$app  = Join-Path $out 'notebook-app'
$wellKnown = Join-Path $app '.well-known'

$fps = @()
if($JsonPath -and (Test-Path $JsonPath)){
  $raw = Get-Content -Raw -LiteralPath $JsonPath
  $j = $raw | ConvertFrom-Json
  if($j.target.sha256_cert_fingerprints){ $fps = @($j.target.sha256_cert_fingerprints) }
  if($j.target.package_name){ $PackageName = $j.target.package_name }
} elseif($Fingerprint){
  $fps = $Fingerprint -split '[,;\s]+' | Where-Object { $_ -match '^[0-9A-Fa-f:]{20,120}$' }
}
$fps = @($fps | ForEach-Object { $_.Trim().ToUpper() } | Where-Object { $_ } | Select-Object -Unique)
if(-not $fps -or $fps.Count -eq 0){
  Write-Host "❌ 没拿到有效的 SHA-256 指纹。请把 PWABuilder 生成的 assetlinks.json 内容发我，或 -Fingerprint ""AA:BB:..."""
  exit 1
}
foreach($f in $fps){
  $parts = $f -split ':'
  if($parts.Count -ne 32){ Write-Host ("⚠️ 指纹值 " + $f + " 不是 32 段，请确认复制完整") }
}

New-Item -ItemType Directory -Force -Path $wellKnown | Out-Null
$fpsLines = ($fps | ForEach-Object { '        "' + $_ + '"' }) -join ",`n"
$json = @"
[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "$PackageName",
      "sha256_cert_fingerprints": [
$fpsLines
      ]
    }
  }
]
"@
# 不带 BOM 写入（Google 的校验器对 BOM 敏感）
$utf8 = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText((Join-Path $wellKnown 'assetlinks.json'), $json, $utf8)

# 同步单文件版 + 重建 zip
$h = Get-Content -Raw -LiteralPath (Join-Path $app 'index.html')
$solo = $h
$solo = $solo.Replace('<link rel="manifest" href="manifest.webmanifest">' + "`n", '')
$solo = $solo.Replace('<link rel="apple-touch-icon" href="apple-touch-icon.png">' + "`n", '')
$solo = $solo.Replace('<link rel="icon" href="icon-192.png">' + "`n", '')
$solo = $solo -replace '(?s)\s*if\("serviceWorker" in navigator.*?\n  \}\n', "`n"
Set-Content -LiteralPath (Join-Path $out 'notebook.html') -Value $solo -Encoding UTF8
Compress-Archive -Path (Join-Path $app '*') -DestinationPath (Join-Path $out 'notebook-app.zip') -CompressionLevel Optimal -Force

Write-Host ""
Write-Host "✅ 已生成: outputs/notebook-app/.well-known/assetlinks.json"
Write-Host ("   包名: " + $PackageName)
Write-Host ("   指纹: " + ($fps -join ", "))
Write-Host ("   指纹段数: " + ((($fps[0]) -split ':').Count) + " (应为 32)")
Write-Host "✅ 已重建 outputs/notebook-app.zip"
Write-Host ""
Write-Host "下一步："
Write-Host "  1) 把 notebook-app.zip 拖到同一个 Netlify 项目覆盖部署"
Write-Host "  2) 浏览器打开验证：https://adorable-ganache-7e425b.netlify.app/.well-known/assetlinks.json"
Write-Host "     （应看到 package_name 与 sha256_cert_fingerprints，Content-Type 为 application/json）"
Write-Host "  3) 部署成功后再安装 APK —— 顺序反了地址栏会赖着不走"

